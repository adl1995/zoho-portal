oauth2client.contrib.multistore_file module
===========================================

.. automodule:: oauth2client.contrib.multistore_file
    :members:
    :undoc-members:
    :show-inheritance:
