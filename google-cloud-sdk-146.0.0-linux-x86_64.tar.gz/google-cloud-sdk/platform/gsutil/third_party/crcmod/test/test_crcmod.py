
import unittest

import crcmod.test

unittest.main(module=crcmod.test)
